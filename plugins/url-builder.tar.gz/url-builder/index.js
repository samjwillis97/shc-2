exports["template-handlers"] = {
  build: () => {
    return "http://localhost:3000";
  },
};
